import UIKit
//array
var myFavoriteMovies = ["Pulp Fiction","Kill Bill","Reserved Dogs",5,true] as [Any]

// as -> casting
// any -> any object


// index
myFavoriteMovies[0]
myFavoriteMovies[1]
myFavoriteMovies[2]
myFavoriteMovies[3]
myFavoriteMovies[4]


var myStringArray = ["Test","Test2","Test3"]

myStringArray[0].uppercased()

myStringArray.count

myStringArray[2]

myStringArray[myStringArray.count - 2]

myStringArray.last

myStringArray.sort()


var myNumberArray = [1,2,3,4,5,6,7,]



//Set
//Unordered collectiıon unique elements
var mySet : Set = [1,2,3,4,5]
var myStringSet : Set = ["a","b","c","a"]

var myInternetArray = [1,2,3,4,5,6,2,1]
var myInternetSet = Set(myInternetArray)

var mySet1 : Set<Int> = [1,2,3]
var mySet2 : Set<Int> = [3,4,5]

var mySet3 = mySet1.union(mySet2)
print(mySet3)


// Dictionary
//key-value pairing

var myFavoriteDirectors = ["Pulp Fiction": "Tarantino","Lock Stock": "Guy Ritchie", "The Dark Knight" : "Cristopher Nolan"]
myFavoriteDirectors["Lock Stock"]
myFavoriteDirectors["The Dark Knight"]

myFavoriteDirectors["Pulp Fiction"] = "Quentin Tarantino"
print(myFavoriteDirectors)


myFavoriteDirectors["Seven Samurai"] = "Akira Kurisoma"
print(myFavoriteDirectors)

var mydictionary = ["Run" : 100 , "Swim" : 200 , "Basketball" : 300]
mydictionary["Run"] 
