import UIKit
//Variables & Constants
// snakes case
//CamelCase

//String

var UserName = "James"
UserName.append("o")
UserName.lowercased()
UserName.uppercased()


var userSurname = "Hetfield"



UserName = "lars"

//integer & double & float

 // integer
let userAge = 50
let myNumber = 4
userAge/myNumber
//double
let userAgeD = 50.0
let myNumberD = 4.0
userAgeD / myNumberD

// boolean

var myBool = false
myBool = true


//-------PART 2---------

var mystring : String = "Hello World"
let anotherNumber : Int = 10

let stringNumber : String = String (20)


// define
let myvariable : String

//initilalization

myvariable = "test"
